package co.metacade.webapp;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;

import java.io.IOException;
import java.util.List;

public class Splash extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    Uri path1 = Uri.parse("android.resource://co.metacade.webapp/"+ R.raw.music);

    ImageView metaicon;
    ImageView rotate_rectangle;
    ImageView rotate_rectanglev;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);



        rotate_rectangle = findViewById(R.id.logometa11);
        rotate_rectanglev = findViewById(R.id.logometa14);

        rotate_right();
        rotate_leftv();

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(Splash.this,path1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }

        getWindow().addFlags( WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        TextView texto1 = findViewById(R.id.title2);
        TextView texto2 = findViewById(R.id.title3);
        Button button_token = findViewById(R.id.play_button);
        Button platform = findViewById(R.id.platform_button);

        metaicon = findViewById(R.id.logometa);

        logoZoomAnimationIn();

        final Handler handler = new Handler();
        handler.postDelayed(() -> {

            @SuppressLint("Recycle") final ValueAnimator animCore1 = ValueAnimator.ofFloat(0.3f, 1f);
            animCore1.setDuration(500);
            animCore1.addUpdateListener(animation -> {
                texto1.setScaleX((Float) animation.getAnimatedValue());
                texto1.setScaleY((Float) animation.getAnimatedValue());
            });

            animCore1.setRepeatMode(ValueAnimator.REVERSE);
            animCore1.start();

            texto1.setVisibility(View.VISIBLE);

        }, 500);

        final Handler handler1 = new Handler();
        handler1.postDelayed(() -> {

            @SuppressLint("Recycle") final ValueAnimator animCore1 = ValueAnimator.ofFloat(0.3f, 1f);
            animCore1.setDuration(500);
            animCore1.addUpdateListener(animation -> {
                texto2.setScaleX((Float) animation.getAnimatedValue());
                texto2.setScaleY((Float) animation.getAnimatedValue());
            });

            animCore1.setRepeatMode(ValueAnimator.REVERSE);
            animCore1.start();
            texto2.setVisibility(View.VISIBLE);
            findViewById(R.id.logometa).setVisibility(View.VISIBLE);
            mediaPlayer.start();

        }, 1000);

        final Handler handler2 = new Handler();
        handler2.postDelayed(() -> {

            @SuppressLint("Recycle") final ValueAnimator animCore1 = ValueAnimator.ofFloat(0.3f, 1f);
            animCore1.setDuration(500);
            animCore1.addUpdateListener(animation -> {
                button_token.setScaleX((Float) animation.getAnimatedValue());
                button_token.setScaleY((Float) animation.getAnimatedValue());
            });

            animCore1.setRepeatMode(ValueAnimator.REVERSE);
            animCore1.start();
            findViewById(R.id.buttons).setVisibility(View.VISIBLE);
            //fire.setVisibility(View.VISIBLE);

            texto2.setVisibility(View.VISIBLE);

        }, 1000);

        final Handler handler3 = new Handler();
        handler3.postDelayed(() -> {

            @SuppressLint("Recycle") final ValueAnimator animCore1 = ValueAnimator.ofFloat(0.3f, 1f);
            animCore1.setDuration(500);
            animCore1.addUpdateListener(animation -> {
                platform.setScaleX((Float) animation.getAnimatedValue());
                platform.setScaleY((Float) animation.getAnimatedValue());
            });

            animCore1.setRepeatMode(ValueAnimator.REVERSE);
            animCore1.start();

        }, 1000);

        button_token.setOnClickListener(view -> {


            Uri uri = Uri.parse("https://token.metacade.co/");
            customtabs(uri);
        });

        platform.setOnClickListener(view -> {

            Uri uri = Uri.parse("https://metacade.co/");
            customtabs(uri);
        });

        findViewById(R.id.x).setOnClickListener(v -> {


            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("twitter://user?screen_name=Metacade_"));
                startActivity(intent);
            } catch (Exception e) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://twitter.com/#!/Metacade_")));
            }


        });

        findViewById(R.id.discord).setOnClickListener(v -> {

            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://discord.com/invite/7XG39NuEKQ")));

        });

        findViewById(R.id.telegram).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=metacade_official"));
            startActivity(intent);
        });

        findViewById(R.id.instagram).setOnClickListener(v -> {
            Uri uri = Uri.parse("http://instagram.com/_u/metacade_");
            Intent likeIng = new Intent(Intent.ACTION_VIEW, uri);

            likeIng.setPackage("com.instagram.android");

            try {
                startActivity(likeIng);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("http://instagram.com/metacade_")));
            }
        });

        findViewById(R.id.linkedin).setOnClickListener(v -> {
            /*
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("linkedin://you"));
            final PackageManager packageManager = getPackageManager();
            @SuppressLint("QueryPermissionsNeeded") final List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
            if (list.isEmpty()) {
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.linkedin.com/profile/view?id=you"));
            }
            startActivity(intent);

             */
        });

        findViewById(R.id.youtube).setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW ,
                    Uri.parse("https://www.youtube.com/channel/UCVA_TZHxuqziubGe1ExEUQg"));
            intent.setComponent(new ComponentName("com.google.android.youtube","com.google.android.youtube.PlayerActivity"));

            PackageManager manager = getPackageManager();
            List<ResolveInfo> infos = manager.queryIntentActivities(intent, 0);
            if (infos.size() > 0) {
                startActivity(intent);
            }else{
                //No Application can handle your intent
                Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/channel/UCVA_TZHxuqziubGe1ExEUQg"));
                startActivity(intent1);
            }
        });
    }

    public void customtabs(Uri uri){

        Intent intent = new Intent(this, CustomTabReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        CustomTabsIntent.Builder customTabsBuilder = new CustomTabsIntent.Builder();
        customTabsBuilder.setDefaultColorSchemeParams(new CustomTabColorSchemeParams.Builder()
                .setToolbarColor(getColor(R.color.black))
                .build());
        customTabsBuilder.addMenuItem("Close", pendingIntent);
        CustomTabsIntent customTabsIntent = customTabsBuilder.build();
        customTabsIntent.intent.setPackage("com.android.chrome");
        customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        customTabsIntent.launchUrl(this, uri);
    }

    public void rotate_right(){

        rotate_rectangle.setImageResource(R.drawable.cuble_blue);

        RotateAnimation rotate = new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(3000);
        rotate.setInterpolator(new LinearInterpolator());
        rotate_rectangle.startAnimation(rotate);

        final Handler handler = new Handler();
        handler.postDelayed(this::rotate_left, 3000);
    }

    public void rotate_left(){

        rotate_rectangle.setImageResource(R.drawable.cube_magenta);

        RotateAnimation rotate = new RotateAnimation(180, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(3000);
        rotate.setInterpolator(new LinearInterpolator());
        rotate_rectangle.startAnimation(rotate);

        final Handler handler = new Handler();
        handler.postDelayed(this::rotate_right, 3000);
    }

    public void rotate_rightv(){

        rotate_rectanglev.setImageResource(R.drawable.triangle_blue);

        RotateAnimation rotate = new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(3000);
        rotate.setInterpolator(new LinearInterpolator());
        rotate_rectanglev.startAnimation(rotate);

        final Handler handler = new Handler();
        handler.postDelayed(this::rotate_leftv, 3000);
    }

    public void rotate_leftv(){

        rotate_rectanglev.setImageResource(R.drawable.triangle_magenta);

        RotateAnimation rotate = new RotateAnimation(180, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotate.setDuration(3000);
        rotate.setInterpolator(new LinearInterpolator());
        rotate_rectanglev.startAnimation(rotate);

        final Handler handler = new Handler();
        handler.postDelayed(this::rotate_rightv, 3000);
    }





    public void logoZoomAnimationOut(){

        final ValueAnimator animCoreIcon = ValueAnimator.ofFloat(0.8f, 1f);
        animCoreIcon.setDuration(1500);
        animCoreIcon.addUpdateListener(animation -> {
            metaicon.setScaleX((Float) animation.getAnimatedValue());
            metaicon.setScaleY((Float) animation.getAnimatedValue());
        });

        animCoreIcon.setRepeatMode(ValueAnimator.REVERSE);
        animCoreIcon.start();

        final Handler handler = new Handler();
        handler.postDelayed(this::logoZoomAnimationIn, 1500);
    }

    public void logoZoomAnimationIn(){

        final ValueAnimator animCoreIcon = ValueAnimator.ofFloat(1f, 0.8f);
        animCoreIcon.setDuration(1500);
        animCoreIcon.addUpdateListener(animation -> {
            metaicon.setScaleX((Float) animation.getAnimatedValue());
            metaicon.setScaleY((Float) animation.getAnimatedValue());
        });

        animCoreIcon.setRepeatMode(ValueAnimator.REVERSE);
        animCoreIcon.start();

        final Handler handler = new Handler();
        handler.postDelayed(this::logoZoomAnimationOut, 1500);
    }


    @Override
    public void onResume(){
        super.onResume();
    }

    @Override
    public void onDestroy(){
        finish();
        System.exit(0);
        mediaPlayer.stop();
        super.onDestroy();
    }

    @Override
    public void onPause(){
        mediaPlayer.stop();
        super.onPause();
    }
}